This is just what I'd like to see happen with Min Min.

I know that this doesn't have much of chance as its mainly up to Ray for balancing

But I figured I'd try and say something anyways


I figured one area where Min Min could appear is the deino restaurant in new Alexandria though this would be a one time encounter 
and it would only be an encounter at night. She would be helping out inside serving customers behind the counter or something along the lines of that


what i'd like to see for the stat changes as it goes up in weight, it would be something along the lines of

Starting: Subpar Attack, Decent Speed

Ending: High Attack Abysmal Speed

the only reason why I'd like to see something along the lines of this is because if you look at the weight changes her arm changes forms (Ram Ram -> Dragon -> MegaWatt) 


This is also something that i would like to see, but I highly doubt that it would be implemented is a move that would change attacks as weight changes.


Since this move would be technically very broken I wouldn't give Min Min any STAB BOOST for this signature move and would be considered the ???/Normal type since it technically is a multitype attack.

Signature Move

Arm Attack


Stage One (Ram Ram)
-------------------------
Base Power: 20

Effect: Hits 2 to 5 times
-- -- -- -- -- -- -- -- --

Stage 2 (Dragon)
--------------------------
Base Power: 60

Effect: has a chance to burn
-- -- -- -- -- -- -- -- -- 

Stage 3 (Megawatt)
---------------------------
Base Power: 120

Effect: has a low chance to cause paralysis, must recharge after attack 



